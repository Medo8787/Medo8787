- # مرحبًا، أنا [MohammedAhmed] 👋

## معلومات عني:
- **📍 العنوان:** [benha city]
- **📞 الهاتف:** [01275694701]
- **📧 البريد الإلكتروني:** [ma20232381@sva.edu.eg]
- **💼 الوظيفة:** [University student]

### **روابط التواصل الاجتماعي:**
- [LinkedIn](https://www.linkedin.com/in/your-profile)
- [https://www.instagram.com/me_________d0?igsh=bWNocDFtM3Z1dHB5](https://Instagram.com/your-handle)
<!---
Medo8787/Medo8787 is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
